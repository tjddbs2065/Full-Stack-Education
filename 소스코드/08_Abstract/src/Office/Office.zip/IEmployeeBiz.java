package Office;

public interface IEmployeeBiz {
	public void addEmployee(Employee employee);
	public boolean isEmployee(Employee employee);
}
