package com.study.lottery;

/** �輺�� */
public class LotteryTest {
	public static void main(String[] args) {
		Lottery lottery = new Lottery();
		
		lottery.rollNumbers();
		
		System.out.println(lottery);
	}
}
