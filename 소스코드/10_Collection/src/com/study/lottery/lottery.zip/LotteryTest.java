package com.study.lottery;

public class LotteryTest {
	public static void main(String[] args) {
		Lottery lottery = new Lottery();
		
		lottery.rollNumbers();
		
		System.out.println(lottery);
	}
}
